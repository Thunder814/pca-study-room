# PCA Lesson 3 — 从零操作 / Start from zero

这是根据本次 meeting 的主题编写的教学示例，不是老师原始代码的逐字复原。
This is a reproducible teaching example based on the meeting, not a verbatim copy of the lecturer's code.

## 打开顺序 / Opening order

1. 先安装 R，再准备免费的 RStudio Desktop。Windows 教程使用当前可获得的 R 4.6.2 和 RStudio 2026.10.1；不要求你强行匹配版本。
   Install R first, then the free RStudio Desktop. The screenshots use R 4.6.2 and RStudio 2026.10.1; exact version matching is not required.
2. 将整个 ZIP 解压到普通文件夹。不要直接在 ZIP 里面运行。
   Extract the entire ZIP into a normal folder. Do not work inside the ZIP.
3. 在 RStudio 中选择 File → Open Project，打开 `PCA_Lesson3.Rproj`。
   In RStudio choose File → Open Project and open `PCA_Lesson3.Rproj`.
4. 打开 `00_first_steps.R`，每次选一小段，按 Ctrl + Enter。
   Open `00_first_steps.R`, select a small block, and press Ctrl + Enter.
5. 主线不需要额外软件包，不必先运行 01。
   The core route needs no extra packages; skip 01 initially.
6. 从头开始分段运行 `02_penguin_pca.R`，再运行 `03_centering_scaling_experiments.R`。
   Run `02_penguin_pca.R` in order, then `03_centering_scaling_experiments.R`.

## 文件用途 / File guide

| 文件 / File | 用途 / Purpose |
| --- | --- |
| `00_first_steps.R` | 加减、赋值、函数 / Arithmetic, assignment, functions |
| `01_install_packages.R` | 可选扩展包 / Optional package installation |
| `02_penguin_pca.R` | 数据、PCA、图、数学核对 / Data, PCA, plots, mathematical checks |
| `03_centering_scaling_experiments.R` | 中心化、标准化和单位实验 / Centering, scaling, and units |
| `04_base_R_fallback.R` | 更短的核心示例 / A shorter core example |
| `05_lecture_packages_optional.R` | 可选课堂绘图库示例 / Optional lecture plotting packages |
| `06_ggplot_experiments_optional.R` | 可选 ggplot 实验图 / Optional ggplot experiments |
| `data/penguins.csv` | 离线数据 / Offline dataset |
| `results/` | 运行代码后保存的图和表 / Figures and tables saved by the code |

## 数据说明 / Data notes

公开数据来自 palmerpenguins，包含 344 行。主示例仅对四个数值变量去除缺失值，保留 342 行。species 和 island 仅用于作图标签，不作为 PCA 输入。老师的清洗规则没有出现在录音中，因此精确数值可能与课堂略有不同。

The public palmerpenguins dataset contains 344 rows. We remove rows missing any of the four numeric measurements, leaving 342. Species and island are plot labels, not PCA inputs. The lecturer's exact cleaning rule was not available, so numerical results may differ slightly from the lecture.

Dataset and attribution: https://allisonhorst.github.io/palmerpenguins/

## 常见问题 / Common problems

- `object 'pca' not found`：先运行创建 pca 的代码。/ Run the code that creates `pca` first.
- `there is no package called ...`：先安装，再加载。/ Install the package before loading it.
- Console 出现 `+`：括号或引号可能未闭合；按 Esc 后重新输入完整代码。/ A bracket or quote may be unfinished; press Esc and enter the complete command.
- 文件找不到：打开 `.Rproj`，再运行 `getwd()`。/ Open the `.Rproj`, then check `getwd()`.
- 安装联网失败：可将 CRAN 地址换为 https://mirrors.tuna.tsinghua.edu.cn/CRAN ，或先使用备用脚本。
  If CRAN downloads fail, try the mirror above or use the base-R fallback.
- 系统明确阻止程序或 DLL：不要反复重装，也不要关闭安全保护；联系学校或设备管理员，或使用获准的电脑/学校提供的 R 环境。
  If the system explicitly blocks a program or DLL, contact IT or use an approved R environment.

本项目不包含老师的录音或私人材料。/ This project contains no meeting audio or private documents.

## 扩展脚本 / Optional scripts

先完成 00 → 02 → 03，再按需运行 01 → 05 → 06。主线已在 R 4.6.2 中验证；本机应用控制阻止了 ggfortify / factoextra 的部分组件，因此扩展脚本未完整验证。

Complete 00 → 02 → 03 first; optionally use 01 → 05 → 06 later. The core route was verified in R 4.6.2. Local application control blocked components of ggfortify / factoextra, so optional scripts were not fully verified here.
