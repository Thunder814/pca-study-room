# 可选课堂包路线；先运行 01_install_packages.R。
# Optional lecture-package route; run 01_install_packages.R first.
# 本机因应用控制阻止组件，未完整验证此扩展脚本。
# Not fully verified here because application control blocked dependencies.
# 从上到下按小节运行 / Run the sections in order
# 首先打开 PCA_Lesson3.Rproj / First open PCA_Lesson3.Rproj

# 1. 每次重新打开 R 都要加载 / Load packages in each new R session
library(palmerpenguins)
library(ggplot2)
library(ggfortify)
library(factoextra)

# 2. 看数据 / Inspect the data
data("penguins", package = "palmerpenguins")
head(penguins)
dim(penguins)
names(penguins)
str(penguins)
# 在 RStudio 中可以取消下一行的 # / Uncomment inside RStudio
# View(penguins)

# 3. 只选择四个数值变量 / Select four numeric measurements
variables <- c("bill_length_mm", "bill_depth_mm",
               "flipper_length_mm", "body_mass_g")

# 只删除这四个变量缺失的行；不要按 sex 等无关列删行。
# Remove rows missing these four values, not rows missing unrelated columns.
keep <- complete.cases(penguins[, variables])
penguins_clean <- as.data.frame(penguins[keep, ])
X <- as.data.frame(penguins_clean[, variables])
dim(X)
colSums(is.na(X))
stopifnot(nrow(X) == 342, ncol(X) == 4, !anyNA(X))

# 品种和岛屿保留作图用，不输入 PCA。
# Species and island are labels for plotting; they are not PCA inputs.
table(penguins_clean$species)
sapply(X, sd)

# 4. 中心化 + 标准化后计算 PCA / Run PCA after centering and scaling
pca <- prcomp(X, center = TRUE, scale. = TRUE)
summary(pca)

# 5. 把数学和 R 对应起来 / Connect the mathematics to R
pca$rotation             # 主方向权重 / Principal direction weights
head(pca$x)              # 个体的新坐标 / Scores for individual penguins
pca$sdev                # 各主成分的标准差 / Standard deviations of the PCs
eigenvalues <- pca$sdev^2
variance_percent <- 100 * eigenvalues / sum(eigenvalues)
variance_table <- data.frame(
  PC = paste0("PC", seq_along(eigenvalues)),
  Eigenvalue = eigenvalues,
  Variance_percent = variance_percent,
  Cumulative_percent = cumsum(variance_percent)
)
print(round(variance_table[, -1], 3))

# 6. 建立输出文件夹 / Create an output folder
dir.create("results", showWarnings = FALSE)
dir.create("data", showWarnings = FALSE)
write.csv(penguins, "data/penguins.csv", row.names = FALSE, na = "")
write.csv(variance_table, "results/variance_table.csv", row.names = FALSE)
write.csv(pca$rotation, "results/direction_weights.csv")
write.csv(cbind(penguins_clean[, c("species", "island")], pca$x),
          "results/pca_scores.csv", row.names = FALSE)

# 7. 碎石图 / Scree plot
p_scree <- fviz_eig(pca, addlabels = TRUE, ylim = c(0, 80)) +
  labs(title = "How much variation does each PC explain?") + theme_minimal(base_size = 14)
print(p_scree)
ggsave("results/01_scree.png", p_scree, width = 8, height = 5, dpi = 160, bg = "white")

# 8. 双标图：点是企鹅，箭头是变量 / Biplot: penguins and variables
p_biplot <- autoplot(pca, data = penguins_clean, colour = "species",
                    loadings = TRUE, loadings.label = TRUE,
                    loadings.label.size = 3.5) +
  labs(title = "Penguins: scores and variable directions") +
  theme_minimal(base_size = 14)
print(p_biplot)
ggsave("results/02_biplot_species.png", p_biplot, width = 9, height = 6, dpi = 160, bg = "white")

# 9. 同一组 PCA 坐标，换分组方式 / Same PCA, different labels
p_island <- autoplot(pca, data = penguins_clean, colour = "island",
                    loadings = FALSE) +
  labs(title = "The same PCA scores, coloured by island") + theme_minimal(base_size = 14)
print(p_island)
ggsave("results/03_scores_island.png", p_island, width = 9, height = 6, dpi = 160, bg = "white")

p_both <- autoplot(pca, data = penguins_clean,
                  colour = "species", shape = "island", loadings = FALSE) +
  labs(title = "Colour = species; shape = island") + theme_minimal(base_size = 14)
print(p_both)
ggsave("results/04_scores_species_island.png", p_both, width = 9, height = 6, dpi = 160, bg = "white")

# 可选：分组椭圆不是 PCA 的必要条件，也不是分类模型。
# Optional: group ellipses are not required by PCA and do not create a classifier.
p_ellipses <- autoplot(pca, data = penguins_clean, colour = "species",
                      frame = TRUE, frame.type = "norm") +
  labs(title = "Optional normal-distribution group ellipses") + theme_minimal(base_size = 14)
print(p_ellipses)
ggsave("results/05_group_ellipses.png", p_ellipses, width = 9, height = 6, dpi = 160, bg = "white")

# 10. 变量图 / Variable correlation circle
variable_results <- get_pca_var(pca)
variable_results$coord
variable_results$contrib
variable_results$cos2

p_variables <- fviz_pca_var(pca, col.var = "cos2", repel = TRUE) +
  labs(title = "Variables: quality of representation in PC1-PC2") + theme_minimal(base_size = 14)
print(p_variables)
ggsave("results/06_variable_circle.png", p_variables, width = 8, height = 7, dpi = 160, bg = "white")

# 11. 按主成分比较贡献度 / Contributions, one PC at a time
p_contrib1 <- fviz_contrib(pca, choice = "var", axes = 1) +
  labs(title = "Which variables contribute to PC1?") + theme_minimal(base_size = 14)
p_contrib2 <- fviz_contrib(pca, choice = "var", axes = 2) +
  labs(title = "Which variables contribute to PC2?") + theme_minimal(base_size = 14)
print(p_contrib1)
print(p_contrib2)
ggsave("results/07_contribution_pc1.png", p_contrib1, width = 8, height = 5, dpi = 160, bg = "white")
ggsave("results/08_contribution_pc2.png", p_contrib2, width = 8, height = 5, dpi = 160, bg = "white")

# 12. 用公式核对输出 / Check the outputs against the mathematics
Z <- scale(X, center = pca$center, scale = pca$scale)
stopifnot(max(abs(Z %*% pca$rotation - pca$x)) < 1e-8)
correlations <- cor(X, pca$x)
contribution_formula <- 100 * pca$rotation^2
cos2_formula <- correlations^2
stopifnot(max(abs(contribution_formula - variable_results$contrib)) < 1e-6)
stopifnot(max(abs(cos2_formula - variable_results$cos2)) < 1e-6)
stopifnot(max(abs(colSums(contribution_formula) - 100)) < 1e-8)
stopifnot(max(abs(rowSums(cos2_formula) - 1)) < 1e-8)

comparison <- data.frame(
  Variable = variables,
  PC1_weight = pca$rotation[, 1],
  PC1_contribution_percent = contribution_formula[, 1],
  PC1_cos2 = cos2_formula[, 1],
  PC1_PC2_cos2 = rowSums(cos2_formula[, 1:2])
)
print(comparison)
write.csv(comparison, "results/contribution_vs_cos2.csv", row.names = FALSE)

# 全部四个 PC 可恢复 Z；两个 PC 通常只能近似恢复。
# All four PCs reconstruct Z; two PCs generally give an approximation.
Z_reconstructed <- pca$x %*% t(pca$rotation)
Z_2PC <- pca$x[, 1:2] %*% t(pca$rotation[, 1:2])
max(abs(Z - Z_reconstructed))
mean((Z - Z_2PC)^2)

saveRDS(pca, "results/pca_model.rds")
capture.output(sessionInfo(), file = "results/sessionInfo.txt")
cat("Lesson complete. Your figures and tables are in results/.\n")

