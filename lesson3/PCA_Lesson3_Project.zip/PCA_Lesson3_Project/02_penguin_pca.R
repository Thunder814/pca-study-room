# PCA 第三课：主线无需额外软件包 / Main lesson: no extra packages needed
# 先打开 PCA_Lesson3.Rproj，再从上到下逐节运行。
# Open PCA_Lesson3.Rproj, then run the sections in order.

# 1. 读取离线数据 / Read the included CSV
penguins <- read.csv("data/penguins.csv", na.strings = c("", "NA"))
head(penguins)
dim(penguins)
names(penguins)
str(penguins)
# View(penguins)  # 在 RStudio 中打开表格 / Open the data viewer

# 2. 选择四个数值变量并去除缺失值 / Select four numeric measurements
variables <- c("bill_length_mm", "bill_depth_mm",
               "flipper_length_mm", "body_mass_g")
keep <- complete.cases(penguins[, variables])
penguins_clean <- penguins[keep, ]
X <- penguins_clean[, variables]
dim(X)
colSums(is.na(X))
stopifnot(nrow(X) == 342, ncol(X) == 4, !anyNA(X))

# 3. 中心化并标准化 / Center and standardise
pca <- prcomp(X, center = TRUE, scale. = TRUE)
summary(pca)
head(pca$x)       # 得分：企鹅在新坐标中的位置 / Scores: new coordinates
pca$rotation     # 权重：主成分方向 / Weights: principal directions
pca$sdev         # 主成分的标准差 / PC standard deviations

# 4. 解释方差 / Explained variance
eigenvalues <- pca$sdev^2
variance_percent <- 100 * eigenvalues / sum(eigenvalues)
variance_table <- data.frame(
  PC = paste0("PC", seq_along(eigenvalues)),
  Eigenvalue = eigenvalues,
  Variance_percent = variance_percent,
  Cumulative_percent = cumsum(variance_percent)
)
print(variance_table)

# 输出位置 / Output folder
dir.create("results", showWarnings = FALSE)
write.csv(variance_table, "results/variance_table.csv", row.names = FALSE)
write.csv(pca$rotation, "results/direction_weights.csv")
write.csv(cbind(penguins_clean[, c("species", "island")], pca$x),
          "results/pca_scores.csv", row.names = FALSE)

# 以下函数只是帮助保存同一幅图，不改变 PCA。
# This helper displays and saves the same plot; it does not change PCA.
save_figure <- function(filename, draw, width = 1400, height = 900) {
  draw()
  png(file.path("results", filename), width = width, height = height, res = 160)
  tryCatch(draw(), finally = dev.off())
  invisible(NULL)
}
species <- factor(penguins_clean$species, levels = c("Adelie", "Chinstrap", "Gentoo"))
island <- factor(penguins_clean$island, levels = c("Biscoe", "Dream", "Torgersen"))
palette_species <- c("#D47245", "#5A6CAE", "#247B70")
short_names <- c("Bill length", "Bill depth", "Flipper length", "Body mass")
pc1_label <- sprintf("PC1 (%.1f%%)", variance_percent[1])
pc2_label <- sprintf("PC2 (%.1f%%)", variance_percent[2])

# 5. 碎石图 / Scree plot
draw_scree <- function() {
  par(mar = c(4, 4, 3, 1))
  bars <- barplot(variance_percent, names.arg = variance_table$PC,
                  col = c("#247B70", "#62A99E", "#A8C8C2", "#D6E5E1"),
                  border = NA, ylim = c(0, 80), ylab = "Explained variance (%)",
                  main = "How much variation does each PC explain?")
  text(bars, variance_percent + 3, sprintf("%.1f%%", variance_percent))
}
save_figure("01_scree.png", draw_scree)

# 6. 样本得分图 / Score plot
draw_scores <- function() {
  plot(pca$x[, 1], pca$x[, 2], col = palette_species[species], pch = 19,
       xlab = pc1_label, ylab = pc2_label, main = "Each point is one penguin")
  abline(h = 0, v = 0, col = "grey85", lty = 3)
  legend("topright", levels(species), col = palette_species, pch = 19, bty = "n")
}
save_figure("02_scores_species.png", draw_scores)

# 7. 双标图 / Biplot
# biplot() 同时缩放样本与变量坐标，不能把上方箭头轴当作原始单位。
# biplot() scales scores and arrows; the arrow axes are not original measurement units.
draw_biplot <- function() {
  par(mar = c(4, 4, 4, 4))
  biplot(pca, xlabs = rep(".", nrow(X)), ylabs = short_names,
         cex = c(0.7, 0.9), col = c("#647E79", "#C46D43"),
         main = "Biplot: penguins and variable directions")
}
save_figure("03_biplot.png", draw_biplot)

# 8. 同一个 PCA，用颜色和形状展示两类标签 / Two labels, same PCA
draw_groups <- function() {
  par(mar = c(4, 4, 3, 7), xpd = FALSE)
  plot(pca$x[, 1], pca$x[, 2], col = palette_species[species],
       pch = c(16, 17, 15)[island], xlab = pc1_label, ylab = pc2_label,
       main = "Colour = species; shape = island")
  legend("topright", legend = c(levels(species), levels(island)),
         col = c(palette_species, rep("grey30", 3)),
         pch = c(rep(16, 3), 16, 17, 15), cex = 0.8, bty = "n")
}
save_figure("04_scores_species_island.png", draw_groups)

# 9. 变量相关圆 / Variable correlation circle
correlations <- cor(X, pca$x)
draw_circle <- function() {
  par(mar = c(4, 4, 3, 2))
  theta <- seq(0, 2*pi, length.out = 361)
  plot(cos(theta), sin(theta), type = "l", asp = 1,
       xlim = c(-1.2, 1.2), ylim = c(-1.2, 1.2), col = "grey65",
       xlab = "Correlation with PC1", ylab = "Correlation with PC2",
       main = "Variables in the PC1-PC2 plane")
  abline(h = 0, v = 0, col = "grey85", lty = 3)
  arrows(0, 0, correlations[, 1], correlations[, 2], length = 0.10,
         col = "#247B70", lwd = 2)
  text(correlations[, 1], correlations[, 2], short_names,
       pos = c(4, 2, 4, 2), cex = 0.75, col = "#1C514B", offset = 0.35)
}
save_figure("05_variable_circle.png", draw_circle, width = 1200, height = 1200)

# 10. 对标准化 PCA，贡献度和 cos² 可以直接用下面的公式计算。
# For this standardised PCA, calculate contribution and cos-squared directly.
contribution <- 100 * pca$rotation^2
cos2 <- correlations^2
comparison <- data.frame(
  Variable = variables,
  PC1_weight = pca$rotation[, 1],
  PC1_contribution_percent = contribution[, 1],
  PC1_cos2 = cos2[, 1],
  PC1_PC2_cos2 = rowSums(cos2[, 1:2])
)
print(comparison)
write.csv(comparison, "results/contribution_vs_cos2.csv", row.names = FALSE)
write.csv(correlations, "results/variable_correlations.csv")
write.csv(contribution, "results/variable_contributions.csv")
write.csv(cos2, "results/variable_cos2.csv")

draw_contribution <- function(axis) {
  par(mar = c(6, 4, 3, 1))
  barplot(contribution[, axis], names.arg = short_names,
          col = "#247B70", border = NA, las = 2, ylim = c(0, 100),
          ylab = "Contribution (%)", main = paste("Variable contributions to PC", axis))
  abline(h = 100/ncol(X), col = "#C46D43", lty = 2)
  mtext("Dashed line = equal contribution (25%)", side = 3, cex = 0.8)
}
save_figure("06_contribution_pc1.png", function() draw_contribution(1))
save_figure("07_contribution_pc2.png", function() draw_contribution(2))

# 11. 数学核对与重建 / Mathematical checks and reconstruction
Z <- scale(X, center = pca$center, scale = pca$scale)
stopifnot(max(abs(Z %*% pca$rotation - pca$x)) < 1e-8)
stopifnot(max(abs(colSums(contribution) - 100)) < 1e-8)
stopifnot(max(abs(rowSums(cos2) - 1)) < 1e-8)
Z_reconstructed <- pca$x %*% t(pca$rotation)
Z_2PC <- pca$x[, 1:2] %*% t(pca$rotation[, 1:2])
max(abs(Z - Z_reconstructed))
mean((Z - Z_2PC)^2)
stopifnot(max(abs(Z - Z_reconstructed)) < 1e-8)
saveRDS(pca, "results/pca_model.rds")
capture.output(sessionInfo(), file = "results/sessionInfo.txt")
cat("Main lesson complete. Figures and tables are in results/.\n")

