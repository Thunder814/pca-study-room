# 老师建议的探索 / Investigations suggested in the meeting
# 先运行 05_lecture_packages_optional.R，加载绘图库并创建所需对象。
# Run 05_lecture_packages_optional.R first to load plotting packages and objects.
# 本机因依赖组件受限，未完整验证此扩展脚本。
# Not fully verified here because dependencies were blocked locally.
stopifnot(exists("X"), exists("pca"), exists("penguins_clean"))
dir.create("results", showWarnings = FALSE)

# A. 固定中心化，比较是否标准化 / Keep centering fixed; compare scaling
pca_unscaled <- prcomp(X, center = TRUE, scale. = FALSE)
summary(pca_unscaled)
pca_unscaled$rotation

fit_table <- function(fit, label) {
  values <- fit$sdev^2
  data.frame(Method = label, PC = paste0("PC", seq_along(values)),
             Percent = 100 * values / sum(values))
}
scaling_results <- rbind(fit_table(pca, "Centred + standardised"),
                         fit_table(pca_unscaled, "Centred, original units"))
print(scaling_results)
p_scaling <- ggplot(scaling_results, aes(PC, Percent, fill = Method)) +
  geom_col(position = "dodge") +
  labs(title = "Scaling changes what counts as a large variation",
       y = "Explained variance (%)") + theme_minimal(base_size = 14)
print(p_scaling)
ggsave("results/09_scaling_comparison.png", p_scaling, width = 9, height = 5, dpi = 160, bg = "white")

# B. 同一只企鹅，克改成千克 / Same penguins, grams changed to kilograms
X_kg <- X
X_kg$body_mass_g <- X_kg$body_mass_g / 1000
pca_kg_raw <- prcomp(X_kg, center = TRUE, scale. = FALSE)
pca_kg_scaled <- prcomp(X_kg, center = TRUE, scale. = TRUE)
unit_results <- rbind(fit_table(pca_unscaled, "Raw: mass in grams"),
                      fit_table(pca_kg_raw, "Raw: mass in kilograms"),
                      fit_table(pca, "Scaled: mass in grams"),
                      fit_table(pca_kg_scaled, "Scaled: mass in kilograms"))
print(unit_results)
stopifnot(max(abs(pca$sdev - pca_kg_scaled$sdev)) < 1e-8)
# 正负号可能翻转；比较绝对值 / Signs may flip; compare absolute weights
stopifnot(max(abs(abs(pca$rotation) - abs(pca_kg_scaled$rotation))) < 1e-8)
write.csv(unit_results, "results/units_experiment.csv", row.names = FALSE)
p_units <- ggplot(unit_results, aes(PC, Percent, fill = Method)) +
  geom_col(position = "dodge") + facet_wrap(~ Method, ncol = 2) +
  guides(fill = "none") + labs(title = "Does changing units change PCA?",
                                y = "Explained variance (%)") + theme_minimal(base_size = 13)
print(p_units)
ggsave("results/10_units_experiment.png", p_units, width = 10, height = 7, dpi = 160, bg = "white")

# C. 固定除数，单独比较中心化 / Use identical divisors; isolate centering
# 重要：scale(center = FALSE, scale = TRUE) 除的是 RMS，不是这里想固定的样本标准差。
# Important: scale(center = FALSE, scale = TRUE) uses an RMS-based divisor.
# 我们先手动除以相同的样本标准差，再比较是否减均值。
# Divide by the same sample SDs first, then compare subtraction of the means.
sample_sd <- sapply(X, sd)
X_fixed_scale <- sweep(as.matrix(X), 2, sample_sd, FUN = "/")
fit_centered <- prcomp(X_fixed_scale, center = TRUE, scale. = FALSE)
fit_uncentered <- prcomp(X_fixed_scale, center = FALSE, scale. = FALSE)
center_metrics <- rbind(fit_table(fit_centered, "Centred: variance share"),
                        fit_table(fit_uncentered, "Uncentred: energy about zero"))
print(center_metrics)
write.csv(center_metrics, "results/centering_metrics.csv", row.names = FALSE)

# 未中心化时，平方奇异值的比例是关于原点的能量比例，不能直接当作中心化方差解释率。
# Without centering, squared singular-value shares describe energy about zero,
# not the same centred variance criterion.
center_coordinates <- rbind(
  data.frame(PC1 = fit_centered$x[, 1], PC2 = fit_centered$x[, 2],
             Method = "Centred", Species = penguins_clean$species),
  data.frame(PC1 = fit_uncentered$x[, 1], PC2 = fit_uncentered$x[, 2],
             Method = "Uncentred", Species = penguins_clean$species)
)
p_center <- ggplot(center_coordinates, aes(PC1, PC2, colour = Species)) +
  geom_point(alpha = 0.7) + geom_vline(xintercept = 0, colour = "grey65") +
  geom_hline(yintercept = 0, colour = "grey65") +
  facet_wrap(~ Method, scales = "free") +
  labs(title = "Centering changes the origin and the fitted directions") +
  theme_minimal(base_size = 13)
print(p_center)
ggsave("results/11_centering_scores.png", p_center, width = 11, height = 5, dpi = 160, bg = "white")

# D. 可选：平移不改变中心化 PCA / Optional: translation and centred PCA
X_shifted <- X
X_shifted$bill_length_mm <- X_shifted$bill_length_mm + 1000
fit_shifted <- prcomp(X_shifted, center = TRUE, scale. = TRUE)
stopifnot(max(abs(pca$sdev - fit_shifted$sdev)) < 1e-8)
stopifnot(max(abs(abs(pca$rotation) - abs(fit_shifted$rotation))) < 1e-8)
cat("Experiments complete. Explain the results in your own words.\n")

