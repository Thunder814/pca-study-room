# 软件包装不上时，先用 R 自带功能学习 / A base-R fallback if packages will not install
# 本项目的 data/penguins.csv 是公开的 palmerpenguins 数据。
# data/penguins.csv contains the public palmerpenguins dataset.
# 这条路线不需要 library()，但图的样式与主教程不同。
# This route needs no extra packages; its plots differ from the main tutorial.

penguins <- read.csv("data/penguins.csv", na.strings = c("", "NA"))
variables <- c("bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g")
keep <- complete.cases(penguins[, variables])
penguins_clean <- penguins[keep, ]
X <- penguins_clean[, variables]
pca <- prcomp(X, center = TRUE, scale. = TRUE)
summary(pca)
head(pca$x)
pca$rotation
barplot(100 * pca$sdev^2 / sum(pca$sdev^2), names.arg = paste0("PC", 1:4),
        ylab = "Explained variance (%)", main = "PCA scree plot")
groups <- factor(penguins_clean$species)
plot(pca$x[, 1], pca$x[, 2], col = as.integer(groups), pch = 19,
     xlab = "PC1", ylab = "PC2", main = "Penguin PCA scores")
legend("topright", legend = levels(groups), col = seq_along(levels(groups)), pch = 19)

