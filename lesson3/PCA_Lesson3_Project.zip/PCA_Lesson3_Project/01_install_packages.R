# 只需在第一次使用这台电脑时安装 / Install once on this computer
# 如果安装失败，修复网络后可以重新运行本文件。
# If installation fails, fix the connection and run this file again.

options(timeout = 600)
mirror <- Sys.getenv("PCA_CRAN_MIRROR", "https://cloud.r-project.org")
options(repos = c(CRAN = mirror))

# 为当前用户创建软件包文件夹 / Create a package library for this user
user_lib <- Sys.getenv("R_LIBS_USER")
if (nzchar(user_lib)) {
  dir.create(user_lib, recursive = TRUE, showWarnings = FALSE)
  .libPaths(c(user_lib, .libPaths()))
}

needed <- c("palmerpenguins", "ggplot2", "ggfortify", "factoextra")
missing <- setdiff(needed, rownames(installed.packages()))
if (length(missing) > 0) {
  # Windows 优先用预编译包；本课不需要先装 Rtools。
  # Prefer precompiled Windows packages; Rtools is not needed for this lesson.
  install.packages(missing, Ncpus = 2,
                  type = if (.Platform$OS.type == "windows") "binary" else getOption("pkgType"))
}

# 这里全部是 TRUE，才说明四个包都安装成功。
# All four values must be TRUE to confirm successful installation.
ready <- vapply(needed, requireNamespace, logical(1), quietly = TRUE)
print(ready)
if (!all(ready)) stop("Some packages are missing. See the installation messages above.")
cat("Ready. Next, open 02_penguin_pca.R.\n")

