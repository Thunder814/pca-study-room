# 第一次运行 R / Your first R commands
# 把光标放在某一行，按 Ctrl + Enter。不要输入 Console 里的 > 符号。
# Place the cursor on a line and press Ctrl + Enter. Do not type the > prompt.

1 + 1
sqrt(9)

# <- 把右边的结果存到左边的名字里 / Assign the result to a name
penguin_mass <- 4000
penguin_mass
penguin_mass / 1000

# c() 把几个值放在一起 / Combine values into a vector
masses <- c(3500, 4000, 4500)
mean(masses)
sd(masses)

# 函数名(输入, 选项) / function_name(input, options)
round(mean(masses), digits = 1)

# 查看当前文件夹 / Show the current working folder
getwd()

