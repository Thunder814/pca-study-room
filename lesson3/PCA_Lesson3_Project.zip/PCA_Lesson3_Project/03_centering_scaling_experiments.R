# 老师建议的探索；只用 R 自带功能 / Meeting investigations, using base R
# 先运行 02_penguin_pca.R / Run 02_penguin_pca.R first
stopifnot(exists("X"), exists("pca"), exists("save_figure"))
fit_table <- function(fit, label) {
  values <- fit$sdev^2
  data.frame(Method = label, PC = paste0("PC", seq_along(values)),
             Percent = 100 * values / sum(values))
}

# A. 固定中心化，比较标准化 / Hold centering fixed; compare scaling
pca_unscaled <- prcomp(X, center = TRUE, scale. = FALSE)
summary(pca_unscaled)
pca_unscaled$rotation
scaling_results <- rbind(fit_table(pca, "Centred + standardised"),
                         fit_table(pca_unscaled, "Centred, original units"))
print(scaling_results)
write.csv(scaling_results, "results/scaling_comparison.csv", row.names = FALSE)
draw_scaling <- function() {
  par(mar = c(4, 4, 3, 1))
  values <- rbind(scaling_results$Percent[1:4], scaling_results$Percent[5:8])
  barplot(values, beside = TRUE, names.arg = paste0("PC", 1:4),
          col = c("#247B70", "#C46D43"), border = NA, ylim = c(0, 110),
          ylab = "Explained variance (%)", main = "What changes when scaling is switched off?")
  legend("topright", c("Standardised", "Original units"),
         fill = c("#247B70", "#C46D43"), bty = "n")
}
save_figure("08_scaling_comparison.png", draw_scaling)

# B. 克改成千克 / Change grams to kilograms
X_kg <- X
X_kg$body_mass_g <- X_kg$body_mass_g / 1000
pca_kg_raw <- prcomp(X_kg, center = TRUE, scale. = FALSE)
pca_kg_scaled <- prcomp(X_kg, center = TRUE, scale. = TRUE)
unit_results <- rbind(fit_table(pca_unscaled, "Raw: grams"),
                      fit_table(pca_kg_raw, "Raw: kilograms"),
                      fit_table(pca, "Standardised: grams"),
                      fit_table(pca_kg_scaled, "Standardised: kilograms"))
print(unit_results)
write.csv(unit_results, "results/units_experiment.csv", row.names = FALSE)
stopifnot(max(abs(pca$sdev - pca_kg_scaled$sdev)) < 1e-8)
stopifnot(max(abs(abs(pca$rotation) - abs(pca_kg_scaled$rotation))) < 1e-8)
draw_units <- function() {
  par(mfrow = c(2, 2), mar = c(3, 4, 3, 1))
  for (label in unique(unit_results$Method)) {
    a <- unit_results[unit_results$Method == label, ]
    barplot(a$Percent, names.arg = a$PC, ylim = c(0, 105),
            col = "#247B70", border = NA, ylab = "Variance (%)", main = label)
  }
  par(mfrow = c(1, 1))
}
save_figure("09_units_experiment.png", draw_units, width = 1400, height = 1100)

# C. 固定除数，单独研究中心化 / Fix the divisors; isolate centering
# scale(center=FALSE, scale=TRUE) 的除数不等同于样本标准差。
# scale(center=FALSE, scale=TRUE) does not use the same sample SDs.
sample_sd <- sapply(X, sd)
X_fixed_scale <- sweep(as.matrix(X), 2, sample_sd, FUN = "/")
fit_centered <- prcomp(X_fixed_scale, center = TRUE, scale. = FALSE)
fit_uncentered <- prcomp(X_fixed_scale, center = FALSE, scale. = FALSE)
center_metrics <- rbind(fit_table(fit_centered, "Centred: variance share"),
                        fit_table(fit_uncentered, "Uncentred: energy about zero"))
print(center_metrics)
write.csv(center_metrics, "results/centering_metrics.csv", row.names = FALSE)
# 未中心化的比例是关于原点的能量比例，不能直接当作中心化方差解释率。
# Uncentred shares describe energy about zero, not the same centred-variance criterion.
draw_centering <- function() {
  par(mfrow = c(1, 2), mar = c(4, 4, 3, 1))
  for (name in c("Centred", "Uncentred")) {
    fit <- if (name == "Centred") fit_centered else fit_uncentered
    plot(fit$x[, 1], fit$x[, 2], col = palette_species[species], pch = 19,
         xlab = "PC1 score", ylab = "PC2 score", main = name,
         xlim = range(c(0, fit$x[, 1])), ylim = range(c(0, fit$x[, 2])))
    abline(h = 0, v = 0, col = "grey65", lty = 2)
  }
  par(mfrow = c(1, 1))
}
save_figure("10_centering_comparison.png", draw_centering, width = 1600, height = 800)

# D. 平移不改变中心化 PCA / Translation leaves centred PCA unchanged
X_shifted <- X
X_shifted$bill_length_mm <- X_shifted$bill_length_mm + 1000
fit_shifted <- prcomp(X_shifted, center = TRUE, scale. = TRUE)
stopifnot(max(abs(pca$sdev - fit_shifted$sdev)) < 1e-8)
stopifnot(max(abs(abs(pca$rotation) - abs(fit_shifted$rotation))) < 1e-8)
cat("Experiments complete. Explain the results in your own words.\n")
